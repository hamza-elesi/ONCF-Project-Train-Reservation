package Model;

import java.sql.Date;

public class Admin implements IAdmin{
    private String id;
    private String user_name;
    private String password;
    private String email;
    private Date createdAt;

    @Override
    public void supprimerTrajet() {

    }

    @Override
    public void modifierTrajet() {

    }

    @Override
    public void ajouter_Trajet() {

    }

    @Override
    public void creerCarteDeReduction() {

    }

    @Override
    public void supprimerCarteDeReduction() {

    }
}
