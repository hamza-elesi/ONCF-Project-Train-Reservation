package Model;

public interface IAdmin {


    void supprimerTrajet();
    void modifierTrajet();
    void ajouter_Trajet();
    void  creerCarteDeReduction();
    void supprimerCarteDeReduction();



}
