package Model;

public interface IVoyageur {
    void acheterBillet();
    void imprimerBillet();
}
